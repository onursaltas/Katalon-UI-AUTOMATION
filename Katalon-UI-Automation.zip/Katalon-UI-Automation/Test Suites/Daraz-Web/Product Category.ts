<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Product Category</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>11992585-9625-459d-958c-3b045f6a034e</testSuiteGuid>
   <testCaseLink>
      <guid>2589025d-ac0a-4f7e-b833-457371811c08</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Product Category View/TC_001</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>825d524c-a5d0-4229-937a-d940831faca6</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Product Category View/TC_006</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>eec547bc-d5af-4f12-9977-20653cae9bc4</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Product Category View/TC_005</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>90c858d7-fd93-47cc-9614-72b23eb04204</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Product Category View/TC_004</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>400ee88e-d108-4bee-9282-8d7d4c252d67</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Product Category View/TC_003</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>719bfa8d-4a73-4c09-94cc-42f61ea819a5</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Product Category View/TC_002</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
