<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Cart</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>f5c9feaa-4f59-4a31-9a51-8bc6f96b7f6f</testSuiteGuid>
   <testCaseLink>
      <guid>4c61da7d-b77d-4c9a-940e-bee6d28dfd1d</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Cart/TC_001</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>be9ee04a-b5fc-4053-8d4b-6fedd46648c7</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Cart/TC_002</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
