<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>signin</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>5af653ee-fa5e-47be-8fc1-a8f726a13c0e</testSuiteGuid>
   <testCaseLink>
      <guid>c8b4844f-0bf5-4432-9f48-ca6bdbb32ba5</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Singin/TC_001</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>6441b1e6-0084-4ec6-9c47-1dfeb744a322</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>false</isRun>
      <testCaseId>Test Cases/Singin/TC_002</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
