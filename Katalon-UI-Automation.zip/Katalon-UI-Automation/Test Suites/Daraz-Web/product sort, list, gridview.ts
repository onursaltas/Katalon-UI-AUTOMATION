<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>product sort, list, gridview</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>e04e8847-417c-49a7-b727-2de7e4e079cb</testSuiteGuid>
   <testCaseLink>
      <guid>b48b2636-9fd1-4211-be47-e76bf18a5cb1</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/ProductSort,list, GridView/TC_001</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>a4c18661-73df-4dcb-abab-2a1aefc61e05</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/ProductSort,list, GridView/TC_002</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>0fe9be38-9edb-4823-a3ea-b8180d8eced3</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/ProductSort,list, GridView/TC_003</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>8a552584-e133-42c1-8dda-ab7243e3a425</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/ProductSort,list, GridView/TC_004</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>d2971269-b18f-489e-82cf-dc9ff2cf5ec2</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/ProductSort,list, GridView/TC_005</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
