<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>view by service</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>f20f957b-e5ab-42d1-abf0-4a38c3a287b1</testSuiteGuid>
   <testCaseLink>
      <guid>9aa70665-0791-4b4f-82bf-48455bc04d69</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/View By Service/TC_001</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>94b442c4-998a-430a-b12f-9e33311d4935</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/View By Service/TC_002</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
