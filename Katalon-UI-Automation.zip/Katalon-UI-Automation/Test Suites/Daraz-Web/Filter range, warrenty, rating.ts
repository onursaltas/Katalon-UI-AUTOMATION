<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Filter range, warrenty, rating</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>4a678040-389e-4a9f-a4a2-2b144e7abc41</testSuiteGuid>
   <testCaseLink>
      <guid>136d059b-0912-4924-bb52-c5025e79c5aa</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Filter range, warrenty, rating/TC_001</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>aef53795-1075-42cf-bb77-72c7ec316e9f</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Filter range, warrenty, rating/TC_002</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
