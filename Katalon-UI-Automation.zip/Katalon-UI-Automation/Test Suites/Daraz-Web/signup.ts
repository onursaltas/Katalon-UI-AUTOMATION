<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>signup</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>d0254a26-466c-462e-b59a-49a4a5cf9db4</testSuiteGuid>
   <testCaseLink>
      <guid>456a55eb-47aa-48b0-8287-90e3d2639561</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Signup/TC_003</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>04be2ded-01fc-4336-9701-30503b93b0fc</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Signup/TC_002</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
