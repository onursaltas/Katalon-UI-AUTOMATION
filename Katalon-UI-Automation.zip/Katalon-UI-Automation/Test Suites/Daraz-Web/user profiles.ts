<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>user profiles</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>7e817966-3bf9-493d-b443-f7af932e3638</testSuiteGuid>
   <testCaseLink>
      <guid>12c6a2e0-71d8-4127-9a65-de39b209d19f</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/User Profiles/TC_001</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>2215da9e-a4a5-4e7b-bb8b-37b9bd54c95e</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/User Profiles/TC_002</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
