<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>search</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>fe2826f4-7306-4186-ad55-038de73492ae</testSuiteGuid>
   <testCaseLink>
      <guid>f613d8f8-e247-49bc-8dc7-ca31bf99a0ff</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Search/TC_001</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>936ac86e-6b98-44f6-83cc-41b984479f1d</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Search/TC_002</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
