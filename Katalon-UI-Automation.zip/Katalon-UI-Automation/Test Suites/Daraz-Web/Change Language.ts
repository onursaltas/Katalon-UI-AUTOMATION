<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Change Language</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>cc4c7afb-a378-4c8d-a1c3-a8db9c9bbe7d</testSuiteGuid>
   <testCaseLink>
      <guid>b63d00fa-9d91-4410-a623-74160ff6dee0</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Change language/TC_001</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>c9a3f7d7-ec1a-49d0-967e-7f98c0fdb10a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Change language/TC_002</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
