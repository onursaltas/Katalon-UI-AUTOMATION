<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>input_email</name>
   <tag></tag>
   <elementGuidId>7a820994-6109-4425-b426-71cba6f9de9b</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>div[class='css-1dbjc4n r-1g94qm0'] input[placeholder='Email Anda']</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div [class='css-1dbjc4n r-1g94qm0'] input[placeholder='Email Anda']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
