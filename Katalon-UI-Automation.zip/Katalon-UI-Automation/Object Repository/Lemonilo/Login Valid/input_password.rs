<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>input_password</name>
   <tag></tag>
   <elementGuidId>095ed8d6-bfc6-47cf-828e-d5386d028179</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>div[class='css-1dbjc4n r-1g94qm0'] input[placeholder='Password Anda']</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div [class='css-1dbjc4n r-1g94qm0'] input[placeholder='Password Anda']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
