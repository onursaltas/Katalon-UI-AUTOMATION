<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_masuk_homepage</name>
   <tag></tag>
   <elementGuidId>425c542b-b76b-475f-9272-edc4314e2e07</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//body/div[@id='__next']/main[1]/div[1]/div[2]/div[8]</value>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div[class='css-1dbjc4n r-1loqt21 r-18u37iz r-1wbh5a2 r-17s6mgv r-19u6a5r r-17toicn r-1otgn73 r-eafdt9 r-1i6wzkk r-lrvibr'] div[class='css-901oao r-1loqt21 r-jurbwo r-1inkyih r-1fakmt9']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
