<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_daftar</name>
   <tag></tag>
   <elementGuidId>989394bc-703e-47be-9049-82a26f2054e5</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
      </entry>
      <entry>
         <key>BASIC</key>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div[class='css-901oao r-jwli3a r-ba7s3 r-a023e6 r-vw2c0b r-ywje51 r-usiww2']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
