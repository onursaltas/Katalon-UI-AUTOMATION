<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>buttonMasuk</name>
   <tag></tag>
   <elementGuidId>adb4a3e9-85b6-4671-b737-ca2c73dff191</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value></value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div[class='Viewweb__StyledView-p5eu6e-0 jWZPOx'] span[class='Textweb__StyledText-sc-1fa9e8r-0 gsQVoM']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
