<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>labelEmailAtauPasswordSalah</name>
   <tag></tag>
   <elementGuidId>c5431e1a-ad1d-46c2-9948-35ec5bd32cc9</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>span[class='Textweb__StyledText-sc-1fa9e8r-0 etlKpB']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
