<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>buttonDaftarSekarang</name>
   <tag></tag>
   <elementGuidId>f2dfa925-0a68-496f-b8af-d0ee62241d9c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value></value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>a[data-qa-id='btn-register'] span[class='Textweb__StyledText-sc-1fa9e8r-0 fiFYdF']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
