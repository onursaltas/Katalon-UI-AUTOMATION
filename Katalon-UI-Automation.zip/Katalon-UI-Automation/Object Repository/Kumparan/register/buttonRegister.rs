<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>buttonRegister</name>
   <tag></tag>
   <elementGuidId>a2df4229-a7bc-4784-a17b-d7c37193fbba</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div[class='Viewweb__StyledView-p5eu6e-0 jWZPOx'] span[class='Textweb__StyledText-sc-1fa9e8r-0 gsQVoM']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
