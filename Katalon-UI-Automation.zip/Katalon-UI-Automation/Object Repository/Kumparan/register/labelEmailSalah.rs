<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>labelEmailSalah</name>
   <tag></tag>
   <elementGuidId>ea55f285-08be-4927-8f12-cbc3a5fc1af3</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>span[class='Textweb__StyledText-sc-1fa9e8r-0 fcYmbp']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
