<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>labelTextTrending</name>
   <tag></tag>
   <elementGuidId>8c5b4ae2-f881-4acf-868d-0ea2860a4673</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
      <entry>
         <key>CSS</key>
         <value>div[class='Viewweb__StyledView-p5eu6e-0 jVQSKl']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>CSS</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
