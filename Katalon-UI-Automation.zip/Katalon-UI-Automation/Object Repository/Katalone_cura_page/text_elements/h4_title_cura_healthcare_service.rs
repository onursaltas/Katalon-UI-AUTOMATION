<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h4_title_cura_healthcare_service</name>
   <tag></tag>
   <elementGuidId>0de77c87-c290-4e54-b2ed-44ee2ac00a9c</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//h4/strong[text()=&quot;CURA Healthcare Service&quot;]</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
